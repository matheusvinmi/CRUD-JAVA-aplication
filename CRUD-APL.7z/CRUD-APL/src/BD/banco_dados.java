/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BD;

/**
 *
 * @author Matheus
 */
public class banco_dados {
    /*
    create database crudapl;
    
    create table usuario(
    id_usuario int primary key auto_increment,
    nome_usuario varchar(55) not null,
    email_usuario varchar(55),
    senha_usuario varchar(55) not null
    );
    */
}
